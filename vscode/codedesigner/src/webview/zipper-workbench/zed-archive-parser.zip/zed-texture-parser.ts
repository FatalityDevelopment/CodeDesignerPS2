// Decoder for Zipper PS2 ".tif" texture records and PAL palettes packed inside
// ZED containers. Pixel data is delivered as RGBA8888, already flipped to top-
// down orientation (the file stores rows bottom-up like real TIFF/GS).

export interface ZedTextureHeader {
  width: number;
  height: number;
  paletteId: number;
  formatA: number;
  formatB: number;
  bpp: number;
  isIndexed: boolean;
}

export interface ZedTexture {
  header: ZedTextureHeader;
  rgba: Uint8Array;
  paletteResolved: boolean;
}

export interface ZedPalette {
  paletteId: number;
  rgba: Uint8Array;
}

const TEXTURE_HEADER_SIZE = 0x20;
const TEXTURE_FOOTER_SIZE = 0x80;
const PALETTE_HEADER_SIZE = 0x10;
const PALETTE_CLUT_SIZE = 0x200;

export function base64ToBytes(value: string): Uint8Array {
  const binary = atob(value);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    out[i] = binary.charCodeAt(i);
  }
  return out;
}

export function parseTextureHeader(bytes: Uint8Array): ZedTextureHeader {
  if (bytes.length < TEXTURE_HEADER_SIZE) {
    throw new Error(`texture too small (${bytes.length} bytes)`);
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const width = view.getUint16(0, true);
  const height = view.getUint16(2, true);
  const paletteId = view.getUint16(8, true);
  const formatA = view.getUint16(12, true);
  const formatB = view.getUint16(14, true);

  // Heuristic: if width*height*1 + 0x20 header + 0x80 footer == total, it's
  // indexed8. If width*height*4 + 0x20 + 0x80 == total, it's RGBA32.
  const indexedSize = width * height + TEXTURE_HEADER_SIZE + TEXTURE_FOOTER_SIZE;
  const rgbaSize = width * height * 4 + TEXTURE_HEADER_SIZE + TEXTURE_FOOTER_SIZE;
  let bpp = 8;
  let isIndexed = true;
  if (bytes.length >= rgbaSize && bytes.length < indexedSize + 64) {
    // mid-sized ambiguous case: keep indexed
  }
  if (bytes.length >= rgbaSize && Math.abs(bytes.length - rgbaSize) < Math.abs(bytes.length - indexedSize)) {
    bpp = 32;
    isIndexed = false;
  }

  return { width, height, paletteId, formatA, formatB, bpp, isIndexed };
}

// Decode a 32-bit RGBA texture (already RGBA, just copy pixel bytes Y-flipped).
function decodeRgba32(bytes: Uint8Array, header: ZedTextureHeader): Uint8Array {
  const { width, height } = header;
  const pixelBytes = width * height * 4;
  const src = bytes.subarray(TEXTURE_HEADER_SIZE, TEXTURE_HEADER_SIZE + pixelBytes);
  return flipRowsRgba(src, width, height);
}

function flipRowsRgba(src: Uint8Array, width: number, height: number): Uint8Array {
  const stride = width * 4;
  const out = new Uint8Array(stride * height);
  for (let y = 0; y < height; y++) {
    const srcRow = (height - 1 - y) * stride;
    out.set(src.subarray(srcRow, srcRow + stride), y * stride);
  }
  return out;
}

// PS2 8-bit palette CLUT shuffle: indices 8-15 swap with 16-23 in every 32-entry
// block. Without this swap, indexed pictures render speckled/noisy.
function shufflePs2Clut(clut: Uint8Array): Uint8Array {
  const out = new Uint8Array(clut.length);
  out.set(clut);
  // CLUT is 256 entries of 2 bytes (RGBA5551) = 512 bytes. Shuffle 8-byte groups
  // in 32-byte chunks: ABCD -> ACBD where each letter is an 8-byte (4 entry)
  // block.
  for (let block = 0; block + 32 <= out.length; block += 32) {
    const tmp = new Uint8Array(8);
    tmp.set(out.subarray(block + 8, block + 16));
    out.set(out.subarray(block + 16, block + 24), block + 8);
    out.set(tmp, block + 16);
  }
  return out;
}

function rgba5551ToRgba8888(clut: Uint8Array): Uint8Array {
  const out = new Uint8Array(256 * 4);
  const view = new DataView(clut.buffer, clut.byteOffset, clut.byteLength);
  for (let i = 0; i < 256; i++) {
    const v = view.getUint16(i * 2, true);
    const r = v & 0x1f;
    const g = (v >> 5) & 0x1f;
    const b = (v >> 10) & 0x1f;
    const a = (v >> 15) & 0x1;
    out[i * 4 + 0] = (r << 3) | (r >> 2);
    out[i * 4 + 1] = (g << 3) | (g >> 2);
    out[i * 4 + 2] = (b << 3) | (b >> 2);
    // PS2 uses STA semantics: 1-bit alpha. Treat 0 alpha as fully transparent
    // only for the all-black entry, otherwise opaque. (Most UI atlases use 0xFF.)
    out[i * 4 + 3] = a ? 255 : (r | g | b ? 255 : 0);
  }
  return out;
}

// Decode a raw CLUT buffer into RGBA8888 with PS2 shuffle. Buffers are either
// 512 bytes (256 entries x RGBA5551) or 1024 bytes (256 entries x RGBA8888).
function decodeClutBuffer(buf: Uint8Array): Uint8Array {
  const shuffled = shufflePs2Clut(buf);
  if (buf.length >= 1024) {
    // Direct RGBA8888 CLUT — just copy through, the PS2 shuffle still applies.
    return shuffled.slice(0, 1024);
  }
  return rgba5551ToRgba8888(shuffled);
}

// Real PAL.ZED files store palettes as triplets of entries:
//   texpal_NNN (size 0, name marker)
//   par        (size 8,  per-palette params)
//   buf        (size 512 or 1024, the CLUT data)
// Walk the entry list and group them.
export function parsePaletteNodes(
  nodes: Array<{ index: number; name: string; data: string }>,
): Map<string, ZedPalette> {
  return parsePaletteEntries(
    nodes.map(n => ({ name: n.name })),
    i => base64ToBytes(nodes[i].data),
  );
}

// Variant that consumes entries already extracted in memory. Used when we've
// drilled into a nested PAL archive via the client-side parser.
export function parsePaletteEntries(
  entries: Array<{ name: string }>,
  getBytes: (i: number) => Uint8Array,
): Map<string, ZedPalette> {
  const result = new Map<string, ZedPalette>();
  for (let i = 0; i < entries.length; i++) {
    const node = entries[i];
    const m = /^texpal_(\d+)$/i.exec(node.name);
    if (!m) { continue; }
    const paletteId = Number(m[1]);
    let bufIndex = -1;
    for (let j = i + 1; j < Math.min(i + 4, entries.length); j++) {
      if (/^buf$/i.test(entries[j].name)) { bufIndex = j; break; }
      if (/^texpal_/i.test(entries[j].name)) { break; }
    }
    if (bufIndex < 0) { continue; }
    try {
      const buf = getBytes(bufIndex);
      if (buf.length < 512) { continue; }
      result.set(node.name, { paletteId, rgba: decodeClutBuffer(buf) });
    } catch { /* skip */ }
  }
  return result;
}

// Decode a full texture, resolving the palette from a parsed palette map if
// needed. Returns rgba pixels in top-down orientation.
export function parseTexture(
  bytes: Uint8Array,
  palettes: Map<string, ZedPalette> | null,
): ZedTexture {
  const header = parseTextureHeader(bytes);

  if (!header.isIndexed) {
    return { header, rgba: decodeRgba32(bytes, header), paletteResolved: true };
  }

  const pixelBytes = header.width * header.height;
  const indices = bytes.subarray(TEXTURE_HEADER_SIZE, TEXTURE_HEADER_SIZE + pixelBytes);

  let palette: ZedPalette | undefined;
  if (palettes) {
    const expectedName = `texpal_${header.paletteId}`;
    palette = palettes.get(expectedName);
    if (!palette) {
      for (const candidate of palettes.values()) {
        if (candidate.paletteId === header.paletteId) {
          palette = candidate;
          break;
        }
      }
    }
  }

  const flat = new Uint8Array(header.width * header.height * 4);
  if (palette) {
    for (let i = 0; i < indices.length; i++) {
      const idx = indices[i] * 4;
      flat[i * 4 + 0] = palette.rgba[idx + 0];
      flat[i * 4 + 1] = palette.rgba[idx + 1];
      flat[i * 4 + 2] = palette.rgba[idx + 2];
      flat[i * 4 + 3] = palette.rgba[idx + 3];
    }
  } else {
    // No palette: render indices as grayscale so the user still sees structure.
    for (let i = 0; i < indices.length; i++) {
      const v = indices[i];
      flat[i * 4 + 0] = v;
      flat[i * 4 + 1] = v;
      flat[i * 4 + 2] = v;
      flat[i * 4 + 3] = 255;
    }
  }

  return {
    header,
    rgba: flipRowsRgba(flat, header.width, header.height),
    paletteResolved: !!palette,
  };
}
