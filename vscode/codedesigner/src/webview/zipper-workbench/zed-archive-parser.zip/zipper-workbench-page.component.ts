import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
  computed,
  effect,
  signal,
} from '@angular/core';
import { IconComponent } from '../shared/icon.component';
import { getVsCodeApi } from '../shared/vscode-api';
import {
  base64ToBytes,
  parsePaletteEntries,
  parsePaletteNodes,
  parseTexture,
  ZedPalette,
  ZedTexture,
} from './zed-texture-parser';
import { ZedModel, looksLikeZedContainer, parseModel } from './zed-model-parser';
import { InspectedZedArchive, parseZedArchive } from './zed-archive-parser';
import { ZedModelRenderer } from './zed-model-renderer';
import {
  GeoEntry,
  GeoScene,
  collectVisualPartNames,
  findSceneNode,
  parseGeoScene,
} from './zed-geo-parser';
import './zipper-workbench-page.css';

interface ZipperEntryInfo {
  index: number;
  name: string;
  path: string;
  size: number;
  kind: string;
  extension?: string;
  type?: number;
}

interface ZipperSaveRecordInfo {
  fieldName: string;
  type: number;
  flags: number;
  count: number;
  valOffset: number;
  tableOffset: number;
  strOffset: number;
}

interface ZipperInspectResult {
  format: string;
  role: string;
  path: string;
  fileName: string;
  size: number;
  summary: string;
  canExtract: boolean;
  entries: ZipperEntryInfo[];
  apache?: { hasFtScore: boolean; hasZSealEtc: boolean } | null;
  zed?: {
    rootValue: number;
    stringBasePointer: number;
    headerWord5C: number;
    dataAlignment: number;
  } | null;
  save?: {
    title: string;
    decryptedSize: number;
    header: {
      saveType: number;
      slotIndex: number;
      dataSize: number;
      moduleCount: number;
      field5C: number;
      field60: number;
    };
    modules: string[];
    records: ZipperSaveRecordInfo[];
  } | null;
}

interface ZipperOperationResult {
  outputDirectory?: string;
  outputPath?: string;
  writtenFiles?: string[];
  count?: number;
  section?: string;
  buildVersion?: string;
  publicModulusHex?: string;
  generatedNewKey?: boolean;
}

type PreviewMode = 'none' | 'texture' | 'model';

@Component({
  selector: 'app-zipper-workbench-page',
  standalone: true,
  imports: [IconComponent],
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="zip-shell">
      <div class="zip-toolbar">
        <div class="zip-title">
          <app-icon name="database" [size]="16" />
          <span>Zipper FileFormats</span>
        </div>
        <div class="zip-toolbar-spacer"></div>
        <button class="zip-btn zip-primary" [disabled]="busy()" (click)="openFile()">
          <app-icon name="harddrive" [size]="14" /> Open
        </button>
        <button class="zip-btn" [disabled]="!result() || busy()" (click)="refresh()">
          <app-icon name="refreshcw" [size]="14" /> Refresh
        </button>
        <button class="zip-btn" [disabled]="!result()?.canExtract || busy()" (click)="extractAll()">
          <app-icon name="save" [size]="14" /> Extract All
        </button>
      </div>

      @if (archiveStack().length > 0) {
        <div class="zip-breadcrumb">
          <button class="zip-btn" (click)="navigateRoot()">
            <app-icon name="harddrive" [size]="13" />
            {{ rootBreadcrumb() }}
          </button>
          @for (layer of archiveStack(); track $index; let i = $index) {
            <span class="zip-breadcrumb-sep">/</span>
            <button class="zip-btn" (click)="navigateToDepth(i + 1)">{{ layer.name }}</button>
          }
          <div class="zip-toolbar-spacer"></div>
          <button class="zip-btn" (click)="navigateBack()">
            <app-icon name="refreshcw" [size]="13" /> Back
          </button>
        </div>
      }

      @if (statusMsg()) {
        <button
          type="button"
          class="zip-status"
          [class.zip-status-error]="statusIsError()"
          [class.zip-status-busy]="busy()"
          [disabled]="!lastRevealPath()"
          (click)="revealLast()">
          {{ statusMsg() }}
        </button>
      }

      <div class="zip-main">
        <aside class="zip-sidebar">
          <div class="zip-path" [title]="result()?.path || ''">
            {{ result()?.path || 'No file selected' }}
          </div>

          <div class="zip-meta">
            <div>
              <span>Format</span>
              <strong>{{ result()?.format || '-' }}</strong>
            </div>
            <div>
              <span>Role</span>
              <strong>{{ roleLabel() }}</strong>
            </div>
            <div>
              <span>Size</span>
              <strong>{{ formatBytes(result()?.size || 0) }}</strong>
            </div>
            <div>
              <span>Items</span>
              <strong>{{ currentEntries().length || saveRecordCount() }}</strong>
            </div>
          </div>

          @if (currentEntries().length) {
            <label class="zip-search">
              <app-icon name="search" [size]="14" />
              <input
                type="text"
                placeholder="Search entries"
                [value]="search()"
                (input)="onSearch($event)" />
            </label>
          }

          @if (isApache()) {
            <div class="zip-side-section">
              <div class="zip-section-title">APACHE00</div>
              <button class="zip-side-btn" [disabled]="busy()" (click)="apacheBuildPatch()">
                <app-icon name="wrench" [size]="14" /> Build Patch
              </button>
              <button class="zip-side-btn" [disabled]="busy() || !result()?.apache?.hasFtScore" (click)="apacheDecrypt('ftscore')">
                <app-icon name="code" [size]="14" /> FTScore
              </button>
              <button class="zip-side-btn" [disabled]="busy() || !result()?.apache?.hasZSealEtc" (click)="apacheDecrypt('zsealetc')">
                <app-icon name="filecode" [size]="14" /> ZSealEtc
              </button>
            </div>
          }

          @if (isSave()) {
            <div class="zip-side-section">
              <div class="zip-section-title">Save</div>
              <button class="zip-side-btn" [disabled]="busy()" (click)="saveExportDecrypted()">
                <app-icon name="save" [size]="14" /> Decrypted
              </button>
              <button class="zip-side-btn" [disabled]="busy()" (click)="saveCraft('active')">
                <app-icon name="plus" [size]="14" /> Active
              </button>
              <button class="zip-side-btn" [disabled]="busy()" (click)="saveCraft('overflow')">
                <app-icon name="zap" [size]="14" /> Overflow
              </button>
              <button class="zip-side-btn" [disabled]="busy()" (click)="saveCraft('extreme')">
                <app-icon name="wrench" [size]="14" /> Extreme
              </button>
              <button class="zip-side-btn" [disabled]="busy()" (click)="saveCraft('all')">
                <app-icon name="workflow" [size]="14" /> All Probes
              </button>
            </div>
          }
        </aside>

        <section class="zip-content">
          @if (!result()) {
            <div class="zip-empty">
              <app-icon name="database" [size]="34" />
              <span>Open a ZDB, ZAR, ZED, APACHE00.ZDB, or SOCOM II SaveGame file.</span>
            </div>
          } @else {
            <div class="zip-head">
              <div class="zip-head-main">
                <div class="zip-file-name">{{ result()?.fileName }}</div>
                <div class="zip-summary">{{ result()?.summary }}</div>
              </div>
              @if (selectedEntry(); as entry) {
                <button class="zip-btn" [disabled]="busy()" (click)="extractEntry(entry)">
                  <app-icon name="save" [size]="14" /> Extract
                </button>
              }
            </div>

            @if (result()?.zed) {
              <div class="zip-kv-row">
                <div><span>Root</span><strong>{{ hex(result()?.zed?.rootValue) }}</strong></div>
                <div><span>String Base</span><strong>{{ hex(result()?.zed?.stringBasePointer) }}</strong></div>
                <div><span>Header 5C</span><strong>{{ hex(result()?.zed?.headerWord5C) }}</strong></div>
                <div><span>Align</span><strong>{{ result()?.zed?.dataAlignment }}</strong></div>
              </div>
            }

            @if (pendingArchiveEntry(); as pending) {
              <div class="zip-preview">
                <div class="zip-preview-stage" style="display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px">
                  <div style="font-size:14px;color:var(--vscode-descriptionForeground)">
                    {{ pending.entryName }} is a nested ZED/ZAR archive ({{ pending.size }} bytes).
                  </div>
                  <button class="zip-btn zip-primary" (click)="enterPendingArchive()">
                    <app-icon name="harddrive" [size]="14" /> Enter Archive
                  </button>
                </div>
                <div class="zip-preview-info">
                  <div>
                    <span>Entry</span>
                    <strong>{{ pending.entryName }}</strong>
                  </div>
                  <div>
                    <span>Size</span>
                    <strong>{{ pending.size }} bytes</strong>
                  </div>
                </div>
              </div>
            }

            @if (selectedEntry() && (previewMode() === 'texture' || previewMode() === 'model')) {
              <div class="zip-preview">
                <div class="zip-preview-stage">
                  @if (previewMode() === 'texture') {
                    <img #previewImg class="zip-preview-pic" [src]="textureDataUrl()" alt="Texture preview" />
                  } @else {
                    <canvas #previewCanvas class="zip-preview-canvas"></canvas>
                  }
                  @if (previewMessage()) {
                    <div class="zip-preview-overlay">{{ previewMessage() }}</div>
                  }
                </div>
                <div class="zip-preview-info">
                  <div class="zip-preview-tabs">
                    <button
                      type="button"
                      class="zip-preview-tab"
                      [class.active]="previewMode() === 'texture'"
                      [disabled]="!canPreviewTexture()"
                      (click)="setPreviewMode('texture')">Texture</button>
                    <button
                      type="button"
                      class="zip-preview-tab"
                      [class.active]="previewMode() === 'model'"
                      [disabled]="!canPreviewModel()"
                      (click)="setPreviewMode('model')">Model</button>
                  </div>
                  @if (previewMode() === 'texture' && texture(); as tex) {
                    <div>
                      <span>Size</span><strong>{{ tex.header.width }} x {{ tex.header.height }}</strong>
                    </div>
                    <div>
                      <span>Format</span><strong>{{ tex.header.isIndexed ? 'Indexed8' : 'RGBA32' }}</strong>
                    </div>
                    <div>
                      <span>Palette</span><strong>{{ paletteLabel(tex) }}</strong>
                    </div>
                  }
                  @if (previewMode() === 'model' && model(); as mdl) {
                    @if (mdl.chunks.length > 1) {
                      <div>
                        <span>Chunk</span>
                        <select class="zip-chunk-select" [value]="selectedChunk()" (change)="onChunkChange($event)">
                          <option [value]="-1">All chunks ({{ mdl.chunks.length }})</option>
                          @for (chunk of mdl.chunks; track chunk.offset; let idx = $index) {
                            <option [value]="idx">{{ chunkLabel(idx, chunk) }}</option>
                          }
                        </select>
                      </div>
                    }
                    <div>
                      <span>Chunks</span><strong>{{ mdl.chunks.length }}</strong>
                    </div>
                    <div>
                      <span>Vertices / Triangles</span><strong>{{ activeVertexCount() }} / {{ activeTriangleCount() }}</strong>
                    </div>
                    @if (mdl.textureRefs.length > 0) {
                      <div>
                        <span>Texture refs</span>
                        <div class="zip-texrefs">
                          @for (ref of mdl.textureRefs; track ref) {
                            <span>{{ ref }}</span>
                          }
                        </div>
                      </div>
                    }
                    <div style="display:flex;gap:6px;flex-wrap:wrap">
                      <button class="zip-btn" (click)="toggleWireframe()">
                        <app-icon name="grid" [size]="13" />
                        {{ wireframe() ? 'Solid' : 'Wireframe' }}
                      </button>
                      <button class="zip-btn" (click)="toggleFlipY()">
                        <app-icon name="refreshcw" [size]="13" />
                        {{ flipY() ? 'Unflip Y' : 'Flip Y' }}
                      </button>
                    </div>
                  }
                </div>
              </div>
            }

            @if (isSave()) {
              <div class="zip-save-grid">
                <div>
                  <div class="zip-section-title">Header</div>
                  <div class="zip-save-fields">
                    <div><span>Title</span><strong>{{ result()?.save?.title || '-' }}</strong></div>
                    <div><span>Save Type</span><strong>{{ hex(result()?.save?.header?.saveType) }}</strong></div>
                    <div><span>Slot</span><strong>{{ result()?.save?.header?.slotIndex }}</strong></div>
                    <div><span>Data Size</span><strong>{{ hex(result()?.save?.header?.dataSize) }}</strong></div>
                    <div><span>Modules</span><strong>{{ result()?.save?.modules?.length || 0 }}</strong></div>
                    <div><span>Decrypted</span><strong>{{ formatBytes(result()?.save?.decryptedSize || 0) }}</strong></div>
                  </div>
                </div>
                <div>
                  <div class="zip-section-title">Modules</div>
                  <div class="zip-module-list">
                    @for (module of result()?.save?.modules || []; track module) {
                      <span>{{ module }}</span>
                    }
                  </div>
                </div>
              </div>
            }

            @if (isSave()) {
              <div class="zip-table-wrap">
                <div class="zip-table zip-record-table">
                  <div class="zip-table-head">
                    <span>Field</span>
                    <span>Type</span>
                    <span>Flags</span>
                    <span>Count</span>
                    <span>Value</span>
                  </div>
                  @for (record of result()?.save?.records || []; track record.fieldName + record.strOffset) {
                    <div class="zip-table-row">
                      <span class="zip-name-cell">{{ record.fieldName || '-' }}</span>
                      <span>{{ hex(record.type, 2) }}</span>
                      <span>{{ hex(record.flags, 2) }}</span>
                      <span>{{ record.count }}</span>
                      <span>{{ hex(record.valOffset) }}</span>
                    </div>
                  }
                </div>
              </div>
            } @else {
              <div class="zip-table-wrap">
                <div class="zip-table">
                  <div class="zip-table-head">
                    <span>Name</span>
                    <span>Kind</span>
                    <span>Size</span>
                    <span>Type</span>
                    <span></span>
                  </div>
                  @if (filteredEntries().length === 0) {
                    <div class="zip-empty-row">No matching entries.</div>
                  }
                  @for (entry of filteredEntries(); track entry.index) {
                    <div
                      role="button"
                      tabindex="0"
                      class="zip-table-row zip-entry-row"
                      [class.active]="selectedEntry()?.index === entry.index"
                      (click)="selectEntry(entry)">
                      <span class="zip-name-cell" [title]="entry.path">{{ entry.path || entry.name }}</span>
                      <span>{{ entry.kind }}</span>
                      <span>{{ formatBytes(entry.size) }}</span>
                      <span>{{ entry.type === undefined ? '-' : hex(entry.type) }}</span>
                      <span class="zip-row-actions">
                        <button class="zip-icon-btn" [disabled]="busy()" title="Extract entry" (click)="extractEntry(entry); $event.stopPropagation()">
                          <app-icon name="save" [size]="13" />
                        </button>
                      </span>
                    </div>
                  }
                </div>
              </div>
            }
          }
        </section>
      </div>
    </div>
  `,
})
export class ZipperWorkbenchPageComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('previewCanvas') private previewCanvas?: ElementRef<HTMLCanvasElement>;

  private readonly vscode = getVsCodeApi();
  private modelRenderer: ZedModelRenderer | null = null;
  private nodeCache = new Map<number, Uint8Array>();
  private inflightNode: number | null = null;
  // Maps a fetched node index back to the selected entry index that triggered
  // the fetch (used when .tif markers redirect to the next texdat entry).
  private nodeAliasForFetch = new Map<number, number>();
  private palettesRequested = false;

  readonly result = signal<ZipperInspectResult | null>(null);
  readonly search = signal('');
  readonly selectedIndex = signal<number | null>(null);
  readonly busy = signal(false);
  readonly statusMsg = signal('');
  readonly statusIsError = signal(false);
  readonly lastOperation = signal<ZipperOperationResult | null>(null);

  readonly palettes = signal<Map<string, ZedPalette> | null>(null);
  readonly paletteMessage = signal('');

  // Stack of inline ZED archives we've drilled into. When non-empty, the
  // entry table at the top level shows the deepest sub-archive's entries and
  // node reads come from the in-memory cache, not the bridge.
  readonly archiveStack = signal<Array<{ name: string; archive: InspectedZedArchive }>>([]);
  // Companion data: textures from sibling _TXR (name -> ZedTexture record bytes
  // + entry index pair) and the parsed scene from sibling _GEO.
  readonly companionTextures = signal<Map<string, Uint8Array> | null>(null);
  readonly companionScene = signal<GeoScene | null>(null);
  readonly previewMode = signal<PreviewMode>('none');
  readonly texture = signal<ZedTexture | null>(null);
  readonly textureDataUrl = signal('');
  readonly model = signal<ZedModel | null>(null);
  readonly previewMessage = signal('');
  readonly wireframe = signal(false);
  readonly flipY = signal(false);
  readonly selectedChunk = signal<number>(-1); // -1 = All chunks

  readonly canPreviewTexture = computed(() => {
    const entry = this.selectedEntry();
    return !!entry && /\.tif$/i.test(entry.name);
  });

  readonly canPreviewModel = computed(() => this.model() !== null);


  // Returns the entry list to display in the table — the current sub-archive
  // when drilled in, otherwise the original inspect result.
  readonly currentEntries = computed<ZipperEntryInfo[]>(() => {
    const stack = this.archiveStack();
    if (stack.length > 0) {
      const archive = stack[stack.length - 1].archive;
      return archive.entries.map(e => ({
        index: e.index,
        name: e.name,
        path: e.name,
        size: e.size,
        kind: e.size === 0 ? 'node' : 'payload',
        type: e.type,
        extension: e.extension,
      }));
    }
    return this.result()?.entries ?? [];
  });

  readonly filteredEntries = computed(() => {
    const current = this.currentEntries();
    const q = this.search().trim().toLowerCase();
    if (!q) { return current; }
    return current.filter(entry =>
      `${entry.name} ${entry.path} ${entry.kind} ${entry.extension ?? ''}`.toLowerCase().includes(q));
  });

  readonly selectedEntry = computed(() => {
    const idx = this.selectedIndex();
    if (idx === null) { return null; }
    const entries = this.currentEntries();
    return entries.find(e => e.index === idx) ?? null;
  });

  // Becomes true when the selected entry's bytes are themselves a ZED-format
  // archive (ZED or ZAR). We park here instead of auto-drilling so the user
  // can keep exploring the parent archive's other entries first.
  readonly pendingArchiveEntry = signal<{ entryIndex: number; entryName: string; size: number } | null>(null);

  readonly lastRevealPath = computed(() => {
    const op = this.lastOperation();
    return op?.outputDirectory ?? op?.outputPath ?? op?.writtenFiles?.[0] ?? '';
  });

  readonly roleLabel = computed(() => {
    switch (this.result()?.role) {
      case 'apache-patch-archive': return 'Apache Patch';
      case 'structured-container': return 'Structure';
      case 'game-save': return 'Game Save';
      case 'archive': return 'Archive';
      default: return this.result()?.role || '-';
    }
  });

  private readonly onMessage = (event: MessageEvent): void => {
    const data = event.data as { type: string; [key: string]: unknown };
    switch (data.type) {
      case 'zipperStatus':
        this.setStatus((data['message'] as string) ?? '', false, !!data['busy']);
        break;
      case 'zipperError':
        this.setStatus((data['message'] as string) ?? 'Zipper operation failed', true, false);
        break;
      case 'zipperLoaded':
        this.result.set((data['result'] as ZipperInspectResult) ?? null);
        this.selectedIndex.set(null);
        this.lastOperation.set(null);
        this.nodeCache.clear();
        this.palettes.set(null);
        this.palettesRequested = false;
        this.archiveStack.set([]);
        this.resetPreview();
        this.setStatus(this.result()?.summary ?? 'File loaded.', false, false);
        this.requestPalettesIfNeeded();
        break;
      case 'zipperOperation':
        this.lastOperation.set((data['result'] as ZipperOperationResult) ?? null);
        this.setStatus((data['message'] as string) ?? 'Operation complete.', false, false);
        break;
      case 'nodeData':
        this.handleNodeData(
          (data['entryIndex'] as number) ?? -1,
          (data['data'] as string) ?? '',
        );
        break;
      case 'nodeError':
        this.previewMessage.set((data['message'] as string) ?? 'Failed to read entry.');
        this.inflightNode = null;
        break;
      case 'paletteFile':
        if ((data['found'] as boolean) && data['nodes']) {
          const palettes = parsePaletteNodes(data['nodes'] as Array<{ index: number; name: string; data: string }>);
          this.palettes.set(palettes);
          this.paletteMessage.set(`Loaded ${palettes.size} palette(s).`);
          this.refreshPreview();
        } else {
          this.paletteMessage.set((data['message'] as string) ?? 'No sibling _PAL.ZED found.');
        }
        break;
      case 'companionFiles': {
        const companions = (data['companions'] as Record<string, { path: string; nodes: Array<{ index: number; name: string; type: number; data: string }> }>) ?? {};
        // PAL
        if (companions['pal']) {
          const palettes = parsePaletteNodes(companions['pal'].nodes);
          this.palettes.set(palettes);
        }
        // TXR -> .tif name to texdat bytes map
        if (companions['txr']) {
          const map = new Map<string, Uint8Array>();
          const nodes = companions['txr'].nodes;
          for (let i = 0; i < nodes.length; i++) {
            if (/\.tif$/i.test(nodes[i].name)) {
              for (let j = i + 1; j < Math.min(i + 3, nodes.length); j++) {
                if (/^texdat$/i.test(nodes[j].name)) {
                  map.set(nodes[i].name.toLowerCase(), base64ToBytes(nodes[j].data));
                  break;
                }
                if (/\.tif$/i.test(nodes[j].name)) { break; }
              }
            }
          }
          this.companionTextures.set(map);
        }
        // GEO -> scene tree
        if (companions['geo']) {
          const scene = parseGeoScene(companions['geo'].nodes as GeoEntry[]);
          this.companionScene.set(scene);
        }
        this.refreshPreview();
        break;
      }
    }
  };

  constructor() {
    effect(() => {
      // Auto-load when the selected entry changes.
      const entry = this.selectedEntry();
      if (!entry) { this.resetPreview(); return; }
      this.beginPreviewForEntry(entry.index, entry.name);
    });
  }

  ngOnInit(): void {
    window.addEventListener('message', this.onMessage);
    this.vscode.postMessage({ type: 'ready' });
  }

  ngAfterViewInit(): void {
    // Renderer is created lazily when first model preview is shown so the
    // canvas element exists.
  }

  ngOnDestroy(): void {
    window.removeEventListener('message', this.onMessage);
    this.modelRenderer?.dispose();
    this.modelRenderer = null;
  }

  openFile(): void {
    this.vscode.postMessage({ type: 'openFile' });
  }

  refresh(): void {
    const file = this.result()?.path;
    if (file) { this.vscode.postMessage({ type: 'refresh', path: file }); }
  }

  extractAll(): void {
    const file = this.result()?.path;
    if (file) { this.vscode.postMessage({ type: 'extractAll', path: file }); }
  }

  extractEntry(entry: ZipperEntryInfo): void {
    const file = this.result()?.path;
    if (!file) { return; }
    this.vscode.postMessage({
      type: 'extractEntry',
      path: file,
      entryIndex: entry.index,
      entryName: entry.name || entry.path,
    });
  }

  saveExportDecrypted(): void {
    const file = this.result()?.path;
    if (file) { this.vscode.postMessage({ type: 'saveExportDecrypted', path: file }); }
  }

  saveCraft(mode: 'active' | 'overflow' | 'extreme' | 'all'): void {
    const file = this.result()?.path;
    if (file) { this.vscode.postMessage({ type: 'saveCraft', path: file, mode }); }
  }

  apacheDecrypt(section: 'ftscore' | 'zsealetc'): void {
    const file = this.result()?.path;
    if (file) { this.vscode.postMessage({ type: 'apacheDecryptSection', path: file, section }); }
  }

  apacheBuildPatch(): void {
    const file = this.result()?.path;
    if (file) { this.vscode.postMessage({ type: 'apacheBuildPatch', path: file }); }
  }

  revealLast(): void {
    const target = this.lastRevealPath();
    if (target) { this.vscode.postMessage({ type: 'revealPath', path: target }); }
  }

  selectEntry(entry: ZipperEntryInfo): void {
    this.selectedIndex.set(entry.index);
  }

  navigateBack(): void {
    this.archiveStack.update(s => s.slice(0, -1));
    this.selectedIndex.set(null);
    this.resetPreview();
  }

  navigateRoot(): void {
    this.archiveStack.set([]);
    this.selectedIndex.set(null);
    this.resetPreview();
  }

  navigateToDepth(depth: number): void {
    this.archiveStack.update(s => s.slice(0, depth));
    this.selectedIndex.set(null);
    this.resetPreview();
  }

  rootBreadcrumb(): string {
    const p = this.result()?.path ?? '';
    const file = p.split(/[\\/]/).pop() ?? p;
    return file || 'Root';
  }

  onSearch(event: Event): void {
    this.search.set((event.target as HTMLInputElement).value);
  }

  isApache(): boolean {
    return this.result()?.role === 'apache-patch-archive';
  }

  isSave(): boolean {
    return this.result()?.role === 'game-save';
  }

  saveRecordCount(): number {
    return this.result()?.save?.records?.length ?? 0;
  }

  formatBytes(bytes: number): string {
    if (!Number.isFinite(bytes) || bytes <= 0) { return '0 B'; }
    if (bytes < 1024) { return `${bytes} B`; }
    if (bytes < 1024 * 1024) { return `${(bytes / 1024).toFixed(1)} KB`; }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }

  hex(value: number | undefined, width = 8): string {
    if (value === undefined || value === null || !Number.isFinite(value)) { return '-'; }
    return '0x' + (value >>> 0).toString(16).toUpperCase().padStart(width, '0');
  }

  private setStatus(message: string, isError: boolean, busy: boolean): void {
    this.statusMsg.set(message);
    this.statusIsError.set(isError);
    this.busy.set(busy);
  }

  setPreviewMode(mode: PreviewMode): void {
    if (mode === 'model' && !this.canPreviewModel()) { return; }
    if (mode === 'texture' && !this.canPreviewTexture()) { return; }
    this.previewMode.set(mode);
    if (mode === 'model') { this.ensureModelRenderer(); }
  }

  toggleWireframe(): void {
    const next = !this.wireframe();
    this.wireframe.set(next);
    this.modelRenderer?.setWireframe(next);
  }

  toggleFlipY(): void {
    const next = !this.flipY();
    this.flipY.set(next);
    this.modelRenderer?.setFlipY(next);
  }

  onChunkChange(event: Event): void {
    const value = Number((event.target as HTMLSelectElement).value);
    this.selectedChunk.set(Number.isFinite(value) ? value : -1);
    this.applyModelToRenderer();
  }


  activeVertexCount(): number {
    const mdl = this.model();
    if (!mdl) { return 0; }
    const chunk = this.selectedChunk();
    if (chunk >= 0 && chunk < mdl.chunks.length) { return mdl.chunks[chunk].vertexCount; }
    return mdl.vertices.length;
  }

  chunkLabel(idx: number, chunk: { vertexCount: number; decodedTriangleCount: number; textureName: string | null }): string {
    // User asked for ".tif should be the name" - lead the label with it.
    const tifName = chunk.textureName ?? '(no texture)';
    const partName = this.partNameFor(idx);
    const stats = `${chunk.vertexCount}v/${chunk.decodedTriangleCount}t`;
    return partName
      ? `${tifName} - ${partName} (#${idx}, ${stats})`
      : `${tifName} (#${idx}, ${stats})`;
  }

  private partNameFor(chunkIdx: number): string | null {
    const scene = this.companionScene();
    const entry = this.selectedEntry();
    if (!scene || !entry) { return null; }
    const sceneNode = findSceneNode(scene, entry.name);
    const parts = collectVisualPartNames(sceneNode);
    return parts[chunkIdx] ?? null;
  }

  activeTriangleCount(): number {
    const mdl = this.model();
    if (!mdl) { return 0; }
    const chunk = this.selectedChunk();
    if (chunk >= 0 && chunk < mdl.chunks.length) { return mdl.chunks[chunk].decodedTriangleCount; }
    return mdl.indices.length / 3;
  }

  paletteLabel(tex: ZedTexture): string {
    if (!tex.header.isIndexed) { return 'n/a (RGBA32)'; }
    return tex.paletteResolved
      ? `texpal_${tex.header.paletteId}`
      : `missing (texpal_${tex.header.paletteId})`;
  }

  private resetPreview(): void {
    this.previewMode.set('none');
    this.texture.set(null);
    this.textureDataUrl.set('');
    this.model.set(null);
    this.previewMessage.set('');
    this.wireframe.set(false);
    this.selectedChunk.set(-1);
    this.pendingArchiveEntry.set(null);
    this.modelRenderer?.setModel(null);
  }

  enterPendingArchive(): void {
    const pending = this.pendingArchiveEntry();
    if (!pending) { return; }
    const bytes = this.nodeCache.get(pending.entryIndex);
    if (!bytes) { return; }
    try {
      const archive = parseZedArchive(bytes);
      this.archiveStack.update(s => [...s, { name: pending.entryName, archive }]);
      this.selectedIndex.set(null);
      this.pendingArchiveEntry.set(null);
      this.resetPreview();
      this.setStatus(`Entered ${pending.entryName} (${archive.entries.length} entries).`, false, false);
      this.loadNestedPalettesForCurrentLayer();
    } catch (err) {
      this.previewMessage.set('Nested archive parse failed: ' + (err instanceof Error ? err.message : String(err)));
    }
  }

  private beginPreviewForEntry(index: number, name: string): void {
    const filePath = this.result()?.path;
    if (!filePath) { return; }

    this.resetPreview();
    const looksTif = /\.tif$/i.test(name);
    this.previewMode.set(looksTif ? 'texture' : 'model');
    this.previewMessage.set('Loading preview...');

    // For .tif entries, pixel data lives in the next `texdat` entry; the .tif
    // itself is a 0-byte name marker. Pull the data entry instead.
    const targetIndex = looksTif ? this.findTextureDataIndex(index) : index;
    if (targetIndex < 0) {
      this.previewMessage.set('No texdat entry found after this .tif marker.');
      return;
    }

    // If we're inside a nested archive, the bytes are already in memory.
    const stackBytes = this.bytesFromActiveArchive(targetIndex);
    if (stackBytes) {
      this.decodePayload(index, stackBytes);
      return;
    }

    const cached = this.nodeCache.get(targetIndex);
    if (cached) {
      this.decodePayload(index, cached);
      return;
    }

    this.inflightNode = targetIndex;
    this.nodeAliasForFetch.set(targetIndex, index);
    this.vscode.postMessage({ type: 'readNode', path: filePath, entryIndex: targetIndex });
  }

  private bytesFromActiveArchive(entryIndex: number): Uint8Array | null {
    const stack = this.archiveStack();
    if (stack.length === 0) { return null; }
    const archive = stack[stack.length - 1].archive;
    return archive.entryData.get(entryIndex) ?? null;
  }

  // When we enter a *_TXR.ZED sub-archive, the matching *_PAL.ZED usually
  // lives next to it in the parent layer (or as a real sibling file on disk
  // when the parent is a regular .zed). Find and parse it inline so indexed
  // textures inside resolve to colour instead of grayscale.
  private loadNestedPalettesForCurrentLayer(): void {
    const stack = this.archiveStack();
    if (stack.length === 0) { return; }
    const current = stack[stack.length - 1];
    const txrMatch = /^(.+?)_TXR(?:\([^)]+\))?\.ZED$/i.exec(current.name);
    if (!txrMatch) { return; }
    const targetPalName = `${txrMatch[1]}_PAL.ZED`.toLowerCase();

    // Look at the parent layer for the matching PAL entry.
    const parent = stack.length >= 2 ? stack[stack.length - 2].archive : null;
    if (!parent) { return; }
    const palEntry = parent.entries.find(e => e.name.toLowerCase() === targetPalName);
    if (!palEntry) { return; }
    const palBytes = parent.entryData.get(palEntry.index);
    if (!palBytes || palBytes.length === 0) { return; }

    try {
      const palArchive = parseZedArchive(palBytes);
      const palettes = parsePaletteEntries(
        palArchive.entries.map(e => ({ name: e.name })),
        i => palArchive.entryData.get(palArchive.entries[i].index) ?? new Uint8Array(0),
      );
      if (palettes.size > 0) {
        this.palettes.set(palettes);
        this.paletteMessage.set(`Loaded ${palettes.size} palette(s) from nested ${palEntry.name}.`);
      }
    } catch { /* leave existing palettes in place */ }
  }

  // For an entry that names a texture (".tif"), find the next entry that holds
  // the pixel bytes. In real UIBF_TXR files the data entry is named "texdat".
  // IMPORTANT: this must read from the *current* layer's entries (sub-archive
  // when drilled in), not the root inspect result.
  private findTextureDataIndex(tifIndex: number): number {
    const entries = this.currentEntries();
    const tif = entries.find(e => e.index === tifIndex);
    if (!tif) { return tifIndex; }
    // If the .tif entry itself has data, use it.
    if (tif.size > 0) { return tifIndex; }
    // Otherwise look at up to the next 3 entries.
    const ordered = entries.slice().sort((a, b) => a.index - b.index);
    const pos = ordered.findIndex(e => e.index === tifIndex);
    for (let k = pos + 1; k < Math.min(pos + 4, ordered.length); k++) {
      const next = ordered[k];
      if (/\.tif$/i.test(next.name)) { break; }
      if (next.size > 0) { return next.index; }
    }
    return -1;
  }

  private handleNodeData(fetchedIndex: number, base64: string): void {
    if (this.inflightNode === fetchedIndex) { this.inflightNode = null; }
    try {
      const bytes = base64ToBytes(base64);
      this.nodeCache.set(fetchedIndex, bytes);
      const aliasFor = this.nodeAliasForFetch.get(fetchedIndex) ?? fetchedIndex;
      this.nodeAliasForFetch.delete(fetchedIndex);
      if (this.selectedEntry()?.index === aliasFor) {
        this.decodePayload(aliasFor, bytes);
      }
    } catch (err) {
      this.previewMessage.set(err instanceof Error ? err.message : String(err));
    }
  }

  private decodePayload(index: number, bytes: Uint8Array): void {
    const entry = this.selectedEntry();
    if (!entry || entry.index !== index) { return; }
    const looksTif = /\.tif$/i.test(entry.name);

    if (looksTif) {
      // Keep texture mode active even on failure so the user sees an error
      // instead of a collapsed pane.
      this.previewMode.set('texture');
      try {
        const tex = parseTexture(bytes, this.palettes());
        this.texture.set(tex);
        this.textureDataUrl.set(textureToDataUrl(tex));
        this.previewMessage.set(
          tex.header.isIndexed && !tex.paletteResolved
            ? `Palette texpal_${tex.header.paletteId} not loaded`
            : ''
        );
      } catch (err) {
        this.texture.set(null);
        this.textureDataUrl.set('');
        this.previewMessage.set('Texture decode failed: ' + (err instanceof Error ? err.message : String(err)));
      }
      return;
    }

    // If this entry is itself a nested ZED archive (e.g. a row inside a ZDB
    // or ZAR container), drill into it inline. Pushing onto the archive stack
    // swaps the entries table to show the sub-archive's children and routes
    // node reads through the cached bytes.
    if (looksLikeZedContainer(bytes)) {
      // Don't drill automatically - the user might want to inspect siblings
      // in the parent archive first. Park the entry and show an Enter button.
      this.previewMode.set('none');
      this.model.set(null);
      this.pendingArchiveEntry.set({
        entryIndex: index,
        entryName: entry.name,
        size: bytes.length,
      });
      // Cache so Enter Archive doesn't need a re-fetch.
      this.nodeCache.set(index, bytes);
      this.previewMessage.set('');
      return;
    }
    this.pendingArchiveEntry.set(null);

    // Anything else: try to parse as a model. Keep the pane open even when no
    // chunks are found, so the user sees diagnostics rather than nothing.
    this.previewMode.set('model');
    try {
      const mdl = parseModel(bytes);
      this.model.set(mdl);
      if (mdl.chunks.length === 0) {
        this.previewMessage.set(
          `No model chunks found (payload ${bytes.length} bytes, first 4 = ${describeMagic(bytes)})`
        );
      } else {
        this.previewMessage.set('');
      }
      setTimeout(() => this.applyModelToRenderer(), 0);
    } catch (err) {
      this.model.set(null);
      this.previewMessage.set('Model decode failed: ' + (err instanceof Error ? err.message : String(err)));
    }
  }

  private refreshPreview(): void {
    const entry = this.selectedEntry();
    if (!entry) { return; }
    const bytes = this.nodeCache.get(entry.index);
    if (bytes) { this.decodePayload(entry.index, bytes); }
  }

  private ensureModelRenderer(): void {
    if (this.modelRenderer || !this.previewCanvas?.nativeElement) { return; }
    this.modelRenderer = new ZedModelRenderer(this.previewCanvas.nativeElement);
  }

  private applyModelToRenderer(): void {
    this.ensureModelRenderer();
    const mdl = this.model();
    if (!this.modelRenderer || !mdl) { return; }

    // Build a per-texture map for every unique .tif referenced by any chunk.
    // Sources, in priority order:
    //   1. Companion _TXR.ZED loaded for the root file
    //   2. .tif/texdat pairs found inside the current sub-archive itself
    const textures: Record<string, { width: number; height: number; rgba: Uint8Array }> = {};
    const palettes = this.palettes();
    const sources = this.buildTifByteMap();

    const needed = new Set<string>();
    for (const c of mdl.chunks) {
      if (c.textureName) { needed.add(c.textureName.toLowerCase()); }
    }
    for (const name of needed) {
      const bytes = sources.get(name);
      if (!bytes) { continue; }
      try {
        const tex = parseTexture(bytes, palettes);
        textures[name] = { width: tex.header.width, height: tex.header.height, rgba: tex.rgba };
      } catch {
        // skip undecodable textures
      }
    }

    this.modelRenderer.setModel(mdl, {
      wireframe: this.wireframe(),
      flipY: this.flipY(),
      chunkIndex: this.selectedChunk(),
      textures,
    });
  }

  // Aggregate all known .tif name -> texdat bytes from every source: the root
  // companion _TXR file and any sub-archive currently on the navigation stack.
  private buildTifByteMap(): Map<string, Uint8Array> {
    const map = new Map<string, Uint8Array>();
    const root = this.companionTextures();
    if (root) {
      for (const [name, bytes] of root) { map.set(name, bytes); }
    }
    for (const layer of this.archiveStack()) {
      const archive = layer.archive;
      const entries = archive.entries;
      for (let i = 0; i < entries.length; i++) {
        if (!/\.tif$/i.test(entries[i].name)) { continue; }
        for (let j = i + 1; j < Math.min(i + 4, entries.length); j++) {
          if (/^texdat$/i.test(entries[j].name)) {
            const data = archive.entryData.get(entries[j].index);
            if (data && data.length > 0) {
              map.set(entries[i].name.toLowerCase(), data);
            }
            break;
          }
          if (/\.tif$/i.test(entries[j].name)) { break; }
        }
      }
    }
    return map;
  }

  private findModelTexture(mdl: ZedModel): { width: number; height: number; rgba: Uint8Array } | null {
    if (!mdl.textureRefs.length) { return null; }
    const entries = this.currentEntries();
    for (const ref of mdl.textureRefs) {
      const entry = entries.find(e => e.name.toLowerCase() === ref.toLowerCase());
      if (!entry) { continue; }
      const cached = this.bytesFromActiveArchive(entry.index) ?? this.nodeCache.get(entry.index);
      if (!cached) {
        // Request asynchronously; will apply on next preview refresh.
        const filePath = this.result()?.path;
        if (filePath && this.archiveStack().length === 0) {
          this.vscode.postMessage({ type: 'readNode', path: filePath, entryIndex: entry.index });
        }
        continue;
      }
      try {
        const tex = parseTexture(cached, this.palettes());
        return { width: tex.header.width, height: tex.header.height, rgba: tex.rgba };
      } catch { /* try next */ }
    }
    return null;
  }

  private requestPalettesIfNeeded(): void {
    const filePath = this.result()?.path;
    if (!filePath || this.palettesRequested) { return; }
    const name = filePath.split(/[\\/]/).pop() ?? '';
    if (!/\.ZED$/i.test(name)) { return; }
    this.palettesRequested = true;
    // Single combined call: provider returns _TXR / _PAL / _GEO companions in
    // one round trip so the preview can wire textures and chunk names without
    // chasing the file system multiple times.
    this.vscode.postMessage({ type: 'readCompanionFiles', path: filePath });
  }
}

function describeMagic(bytes: Uint8Array): string {
  if (bytes.length < 4) { return '(empty)'; }
  return Array.from(bytes.subarray(0, 4))
    .map(b => b.toString(16).padStart(2, '0').toUpperCase())
    .join(' ');
}

function textureToDataUrl(tex: ZedTexture): string {
  const canvas = document.createElement('canvas');
  canvas.width = tex.header.width;
  canvas.height = tex.header.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) { return ''; }
  const image = ctx.createImageData(tex.header.width, tex.header.height);
  image.data.set(tex.rgba);
  ctx.putImageData(image, 0, 0);
  return canvas.toDataURL('image/png');
}
