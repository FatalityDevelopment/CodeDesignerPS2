// Lightweight, client-side parser for ZED containers. Mirrors the C# loader
// in CodeDesigner.Ps2.FileFormats/Zipper/ZED/ZedContainer.cs so we can drill
// into a nested ZED archive (one whose bytes live inside another ZED entry)
// without round-tripping through the bridge.

const FIXED_HEADER_SIZE = 0x64;
const RECORD_SIZE = 0x10;

export interface InspectedZedEntry {
  index: number;
  name: string;
  size: number;
  type: number;
  extension: string;
}

export interface InspectedZedArchive {
  entries: InspectedZedEntry[];
  // Pre-extracted raw bytes for every entry, keyed by entry index.
  entryData: Map<number, Uint8Array>;
  rootValue: number;
  stringBasePointer: number;
  headerWord5C: number;
}

function u32(bytes: Uint8Array, off: number): number {
  return (
    bytes[off] |
    (bytes[off + 1] << 8) |
    (bytes[off + 2] << 16) |
    (bytes[off + 3] << 24)
  ) >>> 0;
}

function readNullTerminated(bytes: Uint8Array, start: number, end: number): string {
  let zero = start;
  while (zero < end && bytes[zero] !== 0) { zero++; }
  let out = '';
  for (let i = start; i < zero; i++) {
    const b = bytes[i];
    if (b >= 0x20 && b <= 0x7e) { out += String.fromCharCode(b); }
  }
  return out;
}

// Inspect a ZED container from raw bytes. Returns the same shape we get from
// the bridge's ZipperInspectResult for a real file, plus the actual payload
// bytes for every entry so sub-views don't need another network call.
export function parseZedArchive(bytes: Uint8Array): InspectedZedArchive {
  if (bytes.length < FIXED_HEADER_SIZE) {
    throw new Error(`Too small for a ZED container (${bytes.length} bytes)`);
  }

  const slotCount = u32(bytes, 0x04);
  if (slotCount === 0) { throw new Error('Invalid slot count'); }

  const stringTableSize = u32(bytes, 0x08);
  const stringBase = u32(bytes, 0x0c);
  const headerWord5C = u32(bytes, 0x5c);
  const bodySize = u32(bytes, 0x54);

  const stringTableStart = FIXED_HEADER_SIZE;
  const stringTableEnd = stringTableStart + stringTableSize;
  if (stringTableEnd > bytes.length) {
    throw new Error('String table exceeds archive size');
  }

  const entryCount = slotCount - 1;
  const firstRecordOffset = FIXED_HEADER_SIZE + stringTableSize + 0x10;
  const recordEnd = firstRecordOffset + entryCount * RECORD_SIZE;
  const bodyStart = bytes.length - bodySize;
  if (bodyStart < recordEnd) {
    throw new Error('Record table overlaps body region');
  }

  const rootValue = u32(bytes, firstRecordOffset - 4);

  const entries: InspectedZedEntry[] = [];
  const entryData = new Map<number, Uint8Array>();

  for (let i = 0; i < entryCount; i++) {
    const recordOffset = firstRecordOffset + i * RECORD_SIZE;
    const namePointer = u32(bytes, recordOffset + 0x00);
    const relativeOffset = u32(bytes, recordOffset + 0x04);
    const size = u32(bytes, recordOffset + 0x08);
    const type = u32(bytes, recordOffset + 0x0c);

    let name = '(unnamed)';
    if (namePointer >= stringBase) {
      const stringOffset = stringTableStart + (namePointer - stringBase);
      if (stringOffset >= stringTableStart && stringOffset < stringTableEnd) {
        name = readNullTerminated(bytes, stringOffset, stringTableEnd);
      }
    }

    let payload = new Uint8Array(0);
    if (size > 0) {
      const payloadStart = bodyStart + relativeOffset;
      const payloadEnd = payloadStart + size;
      if (payloadStart >= bodyStart && payloadEnd <= bytes.length) {
        payload = bytes.subarray(payloadStart, payloadEnd);
      }
    }

    const extension = (() => {
      const dot = name.lastIndexOf('.');
      return dot >= 0 ? name.substring(dot) : '';
    })();

    entries.push({ index: i, name, size, type, extension });
    entryData.set(i, payload);
  }

  return { entries, entryData, rootValue, stringBasePointer: stringBase, headerWord5C };
}
